<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>จองห้องพัก Ferry Park INN</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Kanit" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?=base_url("/asset/main_nd.css?t=".date("i-s"))?>">
  <link rel="stylesheet" href="<?=base_url("/asset/modal.css?t=".date("i-s"))?>">
  <link rel="stylesheet" href="<?=base_url("/asset/setting.css?t=".date("i-s"))?>">
  <link href="/asset/img/hotel.png" rel="shortcut icon" />

  <style>
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #cecece;
      padding: 25px;
    }
    .carousel-inner img {
      width: 100%; /* Set width to 100% */
      min-height: 200px;
    }
    /* Hide the carousel text when the screen is less than 600 pixels wide */
    @media (max-width: 600px) {
      .carousel-caption {
        display: none; 
      }
    }
  </style>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="/">Ferry Park INN</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
		<?php if(!empty($_SESSION['logged_in'])): ?>
		<?php if($_SESSION['admin']): ?>
		<li class=""><a href="/admin/bills">BillManger</a></li>
		<li class=""><a href="/admin/order">AllOrder</a></li>
		<li class=""><a href="/admin/payment">แจ้งชำระ</a></li>
		<li class=""><a href="/admin/repair">RepairList</a></li>
		<?php else: ?>
		<li class=""><a href="/main/myorder">MyOrder</a></li>
		<li class=""><a href="/main/bills">Bill</a></li>
		<li class=""><a href="/main/repair">Repair</a></li>
		<?php endif; ?>
		<?php endif; ?>
      </ul>
      <ul class="nav navbar-nav navbar-right">
		<?php if(empty($_SESSION['logged_in'])): ?>
        <li><a href="/main/login"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
		<li><a href="/main/register"><span class="glyphicon glyphicon-registration-mark"></span> Register</a></li>
		<?php else: ?>
		<li><a href="/main/logout"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
		<?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<!-- Modal -->
<center>
	<div class="modal fade" id="success" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document" style="width:300px;margin-top:10%">
			<div class="modal-content">
				<div class="modal-body">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 130.2 130.2">
					  <circle class="path circle" fill="none" stroke="#73AF55" stroke-width="6" stroke-miterlimit="10" cx="65.1" cy="65.1" r="62.1"/>
					  <polyline class="path check" fill="none" stroke="#73AF55" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" points="100.2,40.2 51.5,88.8 29.8,67.5 "/>
					</svg>
					<h2 style="text-align: center;">สำเร็จ</h2>
					<p class="success" id="s_txt"></p>
				</div>
			</div>
		</div>
	</div>
</center>
<!---------------------------------------------------------------------------------------------->
<!-- Modal -->
<center>
	<div class="modal fade" id="error" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document" style="width:300px;margin-top:10%">
			<div class="modal-content">
				<div class="modal-body">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 130.2 130.2">
						<circle class="path circle" fill="none" stroke="#D06079" stroke-width="6" stroke-miterlimit="10" cx="65.1" cy="65.1" r="62.1"/>
						<line class="path line" fill="none" stroke="#D06079" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" x1="34.4" y1="37.9" x2="95.8" y2="92.3"/>
						<line class="path line" fill="none" stroke="#D06079" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" x1="95.8" y1="38" x2="34.4" y2="92.2"/>
					</svg>
					<h2 style="text-align: center;">ผิดพลาด</h2>
					<p class="error" id="e_txt"></p>
				</div>
			</div>
		</div>
	</div>
</center>