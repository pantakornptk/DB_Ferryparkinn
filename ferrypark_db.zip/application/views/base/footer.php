<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<p style="padding-bottom: 50px"></p>
<!--<footer class="container-fluid text-center">
  <p>Footer Text</p>
</footer>-->

<script>
	function sleep (time) {
	  return new Promise((resolve) => setTimeout(resolve, time));
	}
</script>
</body>
</html>
