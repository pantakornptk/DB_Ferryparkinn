<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model("main_model");
		$this->load->helper('url_helper');
		$this->load->library(array('session'));
		date_default_timezone_set("Asia/Bangkok");
	}
	
	private function _set_view($file, $init) {
		$this->load->view('base/header');
		$this->load->view($file, $init);
        $this->load->view('base/footer');
	}
	
	public function index(){
		$data = new stdClass();
		$data->phase = $this->main_model->get_phase();
		$this->_set_view('index', $data);
	}
	
	public function room($phase){
		$this->main_model->delete_order_expire();
		//if(empty($_SESSION['logged_in'])){
			$data = new stdClass();
			$data->phase = $phase;
			$data->row = $this->main_model->get_info_phase($phase);
			$data->phaseinfo = $this->main_model->get_phase_room_img($phase);
			$data->regis = $this->main_model->get_regis_room($data->row["p_id"]);
			$data->phaseqty = $this->main_model->get_phase_room_qty($phase);
			$tmp_fl = "";
			$tmp_arr = [];
			foreach($data->phaseqty as $tmp){
				if(in_array($tmp["p_floor"], $tmp_arr)){
					array_push($tmp_arr[$tmp["p_floor"]], $tmp["p_type"][$tmp['f_qty']]);
					
				}else{
					$tmp_arr[$tmp["p_floor"]][$tmp["p_type"]] = $tmp['f_qty'];
				}
			}
			$data->row['room'] = $tmp_arr;
			$this->_set_view('panel/room', $data);
		//}
	}
	
	public function login(){
		if(!empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($_SERVER['REQUEST_METHOD'] == 'POST'){
				$row = $this->main_model->get_user_by_username($this->input->post("username"));
				if(empty($row)){
					$data = new stdClass();
					$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> ไม่มีบัญชีนี้</div>';
					$this->_set_view('panel/login', $data);
				}else{
					$data = new stdClass();
					if(password_verify($this->input->post("password"), $row["password"])){
						$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>สำเร็จ!</strong> เข้าสู่ระบบแล้ว<br>ระบบกำลังพาคุณไปหน้าแรก...</div><script> $(document).ready(function(){ sleep(2500).then(() => { location.reload(); }); }); </script>';
						$_SESSION['logged_in'] = true;
						$_SESSION['username'] = $row["username"];
						$_SESSION["admin"] = false;
						if($row["is_admin"]==true){
							$_SESSION["admin"] = true;
						}
					}else{
						$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> รหัสผ่านไม่ถูกต้อง</div>';
					}
					$this->_set_view('panel/login', $data);
				}
			}else{
				$data = new stdClass();
				$this->_set_view('panel/login', $data);
			}
		}
	}
	
	public function register(){
		if(!empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($_SERVER['REQUEST_METHOD'] == 'POST'){
				$tmp_data = array(
					"email" 	=> $this->input->post("username"),
					"password" 	=> $this->input->post("password"),
					"name" 		=> $this->input->post("name"),
					"phone" 	=> $this->input->post("phone")
				);
				if($this->main_model->check_users($tmp_data["email"], 'username')==false){
					if($this->main_model->make_user($tmp_data)){
						$data = new stdClass();
						$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>สำเร็จ!</strong> สมัครบัญชีสำเร็จ</div><script> $(document).ready(function(){ sleep(1000).then(() => { location.replace("/main/login"); }); }); </script>';
						$this->_set_view('panel/register', $data);
					}else{
						$data = new stdClass();
						$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> สมัครบัญชีไม่สำเร็จ</div>';
						$this->_set_view('panel/register', $data);
					}
				}else{
					$data = new stdClass();
					$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> อีเมลล์มีถูกใช้ไปแล้ว</div>';
					$this->_set_view('panel/register', $data);
				}
			}else{
				$data = new stdClass();
				$this->_set_view('panel/register', $data);
			}
		}
	}
	
	public function logout(){
		if(!empty($_SESSION['logged_in'])){
			if(session_destroy()){
				$data = new stdClass();
				$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>สำเร็จ!</strong> ออกจากระบบแล้ว</div><script> $(document).ready(function(){ sleep(1000).then(() => { location.reload(); }); }); </script>';
				$this->_set_view('panel/login', $data);
			}else{
				redirect(base_url('/'));
			}
		}else{
			redirect(base_url('/main/login'));
		}
	}
	
	public function order($room){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/main/login'));
		}else{
			$regis = $this->main_model->get_regis_room("P0".$room[0]);
			if(in_array($room, $regis)){
				redirect(base_url('/room/P0'.$room[0]));
			}else{
				if($_SERVER['REQUEST_METHOD'] == 'POST'){
					$order_id		= $this->main_model->create_order_id();
					$order_name		= $this->input->post('order_name');
					$order_doe		= $this->input->post('order_doe');
					$order_date		= date("Y-m-d H:i:s", strtotime("now"));
					$expired		= date("Y-m-d H:i:s", strtotime($order_date ." + 1 day"));
					$order_email	= $this->input->post('order_email');
					$order_phone	= $this->input->post('order_phone');
					$order_room		= $room;
					$p_id			= "P0".$room[0];
					$status = $this->main_model->insert_order($order_id, $order_name, $order_date, $order_email, $order_phone, $order_room, $p_id, $expired, $order_doe);
					$data = new stdClass();
					$data->room = $room;
					$data->phase = $room[0];
					$data->ordered = true;
					$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong></strong> จองสำเร็จ!</div>';
					$this->_set_view('panel/order', $data);
				}else{
					$data = new stdClass();
					$data->room = $room;
					$data->phase = $room[0];
					$data->user = $this->main_model->get_user_by_username($_SESSION["username"]);
					$this->_set_view('panel/order', $data);
				}
			}
		}
	}
	
	public function myorder(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/main/login'));
		}else{
			$data = new stdClass();
			$data->rows = $this->main_model->get_order_by_user($_SESSION["username"]);
			$this->_set_view('panel/myorder', $data);
		}
	}
	
	public function cancle($orderid){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/main/login'));
		}else{
			if($this->main_model->check_order_by_user($orderid, $_SESSION["username"])){
				$this->main_model->delete_order($orderid);
				redirect(base_url('/main/myorder'));
			}else{
				redirect(base_url('/main/myorder'));
			}
		}
	}
	
	public function cancle_payment($orderid){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/main/login'));
		}else{
			if($this->main_model->check_order_by_user($orderid, $_SESSION["username"])){
				unlink($this->main_model->check_payment($orderid)['img']);
				$this->main_model->delete_payment($orderid);
				$this->main_model->update_order_waiting($orderid);
				redirect(base_url('/main/myorder'));
			}else{
				redirect(base_url('/main/myorder'));
			}
		}
	}
	
	public function payment($orderid){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/main/login'));
		}else{
			if($this->main_model->check_order_by_user($orderid, $_SESSION["username"])){
				if($_SERVER['REQUEST_METHOD'] == 'POST'){
					$config['upload_path'] = "upload/";
					$config['allowed_types'] = 'jpg|png';
					$this->load->library('upload', $config);
					if(!$this->upload->do_upload('file')){
						$data = new stdClass();
						$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> อัพโหลดไม่สำเร็จ</div>';
						$data->orderid = $orderid;
						$data->paid = $this->main_model->check_payment($orderid);
						$this->_set_view('panel/payment', $data);
					}else{
						$data2 = array('upload_data' => $this->upload->data());
						$d = array(
							"order_id" => $orderid,
							"amount" => $this->input->post('amount')
						);
						$d['link'] = 'upload/'.$data2['upload_data']['file_name'];
						$this->main_model->insert_payment($d);
						$this->main_model->update_order($orderid);
						$data = new stdClass();
						$data->orderid = $orderid;
						$data->paid = $this->main_model->check_payment($orderid);
						$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>สำเร็จ!</strong> แจ้งชำระแล้ว</div>';
						$this->_set_view('panel/payment', $data);
					}
				}else{
					$data = new stdClass();
					$data->orderid = $orderid;
					$data->paid = $this->main_model->check_payment($orderid);
					$this->_set_view('panel/payment', $data);
				}
			}else{
				redirect(base_url('/main/myorder'));
			}
		}
	}
	
	public function repair(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/main/login'));
		}else{
			if($_SERVER['REQUEST_METHOD'] == 'POST'){
				$d = array(
					"rid"		=>$this->main_model->create_repair_id(),
					"rdate"		=>date("Y-m-d H:i:s", strtotime("now")),
					"rdoe" 		=>$this->input->post("rdate"),
					"rdetail" 	=>$this->input->post("rdetail"),
					"order_id" 	=>$this->input->post("order_id"),
				);
				$this->main_model->insert_repair($d);
				$data = new stdClass();
				$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>สำเร็จ!</strong> แจ้งซ่อมแล้ว</div>';
				$data->orders = $this->main_model->get_order_repair_by_user($_SESSION["username"]);
				$this->_set_view('panel/repair', $data);
			}else{
				$data = new stdClass();
				$data->orders = $this->main_model->get_order_repair_by_user($_SESSION["username"]);
				$this->_set_view('panel/repair', $data);
			}
		}
	}
	
	public function bill($orderid){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/main/login'));
		}else{
			$data = new stdClass();
			$data->row = $this->main_model->get_order_by_id($orderid);
			$this->_set_view('panel/billorder', $data);
		}
	}
	
	public function bills($bid=false){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/main/login'));
		}else{
			$data = new stdClass();
			$data->bills = $this->main_model->get_bill_by_user($_SESSION["username"]);
			if($bid!=false){
				$data->info = $this->main_model->get_bill_by_id($bid);
				$tmp = $this->main_model->get_order_by_id($data->info["order_id"]);
				$data->info["order_room"] = $tmp[0]["order_room"];
				$data->info["order_name"] = $tmp[0]["order_name"];
			}
			$this->_set_view('panel/bills', $data);
		}
	}
}
