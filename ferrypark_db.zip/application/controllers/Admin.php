<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model("main_model");
		$this->load->helper('url_helper');
		$this->load->library(array('session'));
		date_default_timezone_set("Asia/Bangkok");
	}
	
	private function _set_view($file, $init) {
		$this->load->view('base/header');
		$this->load->view($file, $init);
        $this->load->view('base/footer');
	}
	
	public function order(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/main/login'));
		}else{
			if($_SESSION['admin']){
				$data = new stdClass();
				$data->rows = $this->main_model->get_order();
				$this->_set_view('panel/admin/order', $data);
			}
		}
	}
	
	public function payment(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/main/login'));
		}else{
			if($_SESSION['admin']){
				$data = new stdClass();
				$data->rows = $this->main_model->get_payment();
				for($i=0;$i<count($data->rows);$i++){
					$data->rows[$i]["amount_n"] = $this->main_model->get_order_by_id($data->rows[$i]["order_id"])[0]["order_payment"];
				}
				$this->_set_view('panel/admin/payment', $data);
			}
		}
	}
	
	public function confirm_payment($orderid){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/main/login'));
		}else{
			if($_SESSION['admin']){
				$this->main_model->update_order_success($orderid);
				$this->main_model->delete_payment($orderid);
				redirect(base_url('/admin/payment'));
			}else{
				redirect(base_url('/'));
			}
		}
	}
	
	public function cancle_payment($orderid){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/main/login'));
		}else{
			if($_SESSION['admin']){
				$this->main_model->update_order_deny($orderid);
				$this->main_model->delete_payment($orderid);
				redirect(base_url('/admin/payment'));
			}else{
				redirect(base_url('/'));
			}
		}
	}
	
	public function repair(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/main/login'));
		}else{
			if($_SESSION['admin']){
				$data = new stdClass();
				$data->rows = $this->main_model->get_repair();
				$this->_set_view('panel/admin/repair', $data);
			}else{
				redirect(base_url('/'));
			}
		}
	}
	
	public function bills(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/main/login'));
		}else{
			if($_SESSION['admin']){
				if($_SERVER['REQUEST_METHOD'] == 'POST'){
					$d = array(
						"b_id"			=> $this->main_model->create_bill_id(),
						"b_water"		=> $this->input->post("b_water"),
						"b_elec"		=> $this->input->post("b_elec"),
						"b_room"		=> $this->input->post("b_room"),
						"b_other"		=> $this->input->post("b_other"),
						"b_date"		=> $this->input->post("b_date"),
						"b_due"			=> $this->input->post("b_due"),
						"order_id"		=> $this->input->post("order_id")
					);
					$this->main_model->insert_bill($d);
					$data = new stdClass();
					$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>สำเร็จ!</strong> เพิ่มบิลแล้ว</div>';
					$data->orders = $this->main_model->get_order_id("ASC");
					$this->_set_view('panel/admin/addbill', $data);
				}else{
					$data = new stdClass();
					$data->orders = $this->main_model->get_order_id("ASC");
					$this->_set_view('panel/admin/addbill', $data);
				}
			}else{
				redirect(base_url('/'));
			}
		}
	}
	
}
