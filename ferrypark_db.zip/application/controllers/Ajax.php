<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model("main_model");
		$this->load->helper('url_helper');
		$this->load->library(array('session'));
		date_default_timezone_set("Asia/Bangkok");
	}
	
	private function _set_view($file, $init) {
		$this->load->view('base/header');
		$this->load->view($file, $init);
        $this->load->view('base/footer');
	}
	
	public function action(){
		if(isset($_GET['get_detail'])){
			$row = $this->main_model->get_phase_room_img($_GET['pid']);
			$myJSON = json_encode($row, JSON_UNESCAPED_SLASHES);
			echo $myJSON;
		}elseif(isset($_GET['get_detail_info'])){
			$row = $this->main_model->get_phase_room_info($_GET['pid']);
			$myJSON = json_encode($row, JSON_UNESCAPED_SLASHES);
			echo $myJSON;
		}elseif(isset($_POST["getroom"])){
			echo $this->main_model->get_order_by_id($_POST["orderid"])[0]["order_room"];
		}
	}
	
	public function action_order(){
		if(!empty($this->input->post('order'))){
			$order_id		= $this->main_model->create_order_id();
			$order_name		= $this->input->post('order_name');
			$order_date		= date("Y-m-d H:i:s", strtotime("now"));
			$expired		= date("Y-m-d H:i:s", strtotime($order_date ." + 1 day"));
			$order_email	= $this->input->post('order_email');
			$order_phone	= $this->input->post('order_phone');
			$order_room		= $this->input->post('order_room');
			$p_id			= $this->input->post('p_id');
			$status = $this->main_model->insert_order($order_id, $order_name, $order_date, $order_email, $order_phone, $order_room, $p_id, $expired);
			echo $status;
		}else{
			echo false;
		}
	}
}
