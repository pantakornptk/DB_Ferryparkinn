<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main_model extends CI_Model {
	
	public function __construct() {
		parent::__construct();
		$this->load->database();
		date_default_timezone_set("Asia/Bangkok");
	}
	
	public function get_phase(){
		$query = $this->db->get('phase');
		return $query->result_array();
	}
	
	public function get_repair(){
		$query = $this->db->get('repair');
		return $query->result_array();
	}
	
	public function get_info_phase($id){
		$this->db->from('phase');
		$this->db->where('p_id', $id);
		return $this->db->get()->row_array();
	}
	
	public function get_phase_room_img($id){
		$this->db->where('p_id', $id);
		$query = $this->db->get('phase_img_src');
		$row = $query->result_array();
		
		for($i=0;$i<count($row);$i++){
			
			$tmp = explode(",", $row[$i]['p_img_src']);
			
			unset($row[$i]['p_img_src']);
			
			for($j=0;$j<count($tmp);$j++){
				$row[$i]['p_img_src'][$j] = $tmp[$j];
			}
		}
		return $row;
	}
	
	public function get_regis_room($id){
		$this->db->select("order_room");
		$this->db->where('p_id', $id);
		$this->db->where('order_status !=', "deny");
		$query = $this->db->get('orders');
		$row = $query->result_array();
		
		$arr = [];
		
		for($i=0;$i<count($row);$i++){
			$arr[$i] = $row[$i]['order_room'];
		}
		return $arr;
	}
	
	public function get_phase_room_info($id){
		$this->db->where('p_id', $id);
		$query = $this->db->get('phase_info');
		return $query->result_array();
	}
	
	public function get_order_id($orderby="DESC"){
		$this->db->select("order_id");
		$this->db->order_by('order_id', $orderby);
		$query = $this->db->get('orders');
		return $query->result_array();
	}
	
	public function get_repair_id(){
		$this->db->select("rid");
		$this->db->order_by('rid', 'DESC');
		$query = $this->db->get('repair');
		return $query->result_array();
	}
	
	public function get_bill_id(){
		$this->db->select("b_id");
		$this->db->order_by('b_id', 'DESC');
		$query = $this->db->get('bills');
		return $query->result_array();
	}
	
	public function get_user_by_username($username){
		$this->db->from('users');
		$this->db->where('username', $username);
		return $this->db->get()->row_array();
	}
	
	public function get_phase_room_qty($pid){
		$this->db->from('phase_info');
		$this->db->where('p_id', $pid);
		$this->db->order_by('p_floor', 'ASC');
		return $this->db->get()->result_array();
	}
	
	public function get_order_by_user($user){
		$this->db->from('orders');
		$this->db->where('order_email', $user);
		return $this->db->get()->result_array();
	}
	
	public function get_order_repair_by_user($user){
		$this->db->from('orders');
		$this->db->where('order_email', $user);
		$this->db->where('order_status', "success");
		return $this->db->get()->result_array();
	}
	
	public function get_order_by_id($id){
		$this->db->from('orders');
		$this->db->where('order_id', $id);
		return $this->db->get()->result_array();
	}
	
	public function get_order(){
		$this->db->from('orders');
		return $this->db->get()->result_array();
	}
	
	public function get_payment(){
		$this->db->from('payment');
		return $this->db->get()->result_array();
	}
	
	public function create_order_id(){
		$row = $this->get_order_id();
		if(!empty($row)){
			$order_id = $row[0]['order_id'];
			$tmp = explode("OR",$order_id);
			$tmp[1] += 1;
			$tmp[1] = str_pad($tmp[1], 3, '0', STR_PAD_LEFT);
			$order_id = "OR".$tmp[1];
			
			return $order_id;
		}else{
			return "OR001";
		}
	}
	
	public function create_repair_id(){
		$row = $this->get_repair_id();
		if(!empty($row)){
			$order_id = $row[0]['rid'];
			$tmp = explode("R",$order_id);
			$tmp[1] += 1;
			$tmp[1] = str_pad($tmp[1], 3, '0', STR_PAD_LEFT);
			$order_id = "R".$tmp[1];
			
			return $order_id;
		}else{
			return "R001";
		}
	}
	
	public function create_bill_id(){
		$row = $this->get_bill_id();
		if(!empty($row)){
			$order_id = $row[0]['b_id'];
			$tmp = explode("B",$order_id);
			$tmp[1] += 1;
			$tmp[1] = str_pad($tmp[1], 3, '0', STR_PAD_LEFT);
			$order_id = "B".$tmp[1];
			
			return $order_id;
		}else{
			return "B001";
		}
	}
	
	public function insert_repair($data){
		return $this->db->insert('repair', $data);
	}
	
	public function insert_bill($data){
		return $this->db->insert('bills', $data);
	}
	
	public function insert_order($order_id, $order_name, $order_date, $order_email, $order_phone, $order_room, $p_id, $expired, $order_doe){
		$pid = "P0".$order_room[0];
		$fl = "FL".$order_room[1];
		$room = $order_room[2].$order_room[3];
		$row = array(
			"order_id" => $order_id,
			"order_name" => $order_name,
			"order_date" => $order_date,
			"order_email" => $order_email,
			"order_phone" => $order_phone,
			"order_room" => $order_room,
			"p_id" => $p_id,
			"order_expire" => $expired,
			"order_status" => "waiting",
			"order_payment" => $this->get_price($pid, $fl, $room),
			"order_doe" => $order_doe
		);
		return $this->db->insert('orders', $row);
	}
	
	public function get_price($pid, $fl,$room){
		$this->db->where('p_id', $pid);
		$this->db->where('p_floor', $fl);
		$query = $this->db->get('phase_info');
		$row = $query->result_array();
		if($room < $row[0]["f_qty"]){
			return $row[0]["p_price"];
		}else{
			return $row[1]["p_price"];
		}
	}
	
	public function make_user($data){
		$row = array(
			"id" => NULL,
			"username" => $data["email"],
			"password" => password_hash($data["password"], PASSWORD_DEFAULT),
			"is_admin" => 0,
			"name"	   => $data["name"],
			"phone"	   => $data["phone"]
		);
		return $this->db->insert('users', $row);
	}
	
	public function delete_order_expire(){
		$now = date("Y-m-d H:i:s", strtotime("now"));
		$this->db->where('order_expire <', $now);
		$this->db->where('order_status !=', "success");
		$this->db->where('order_status !=', "pending");
		$query = $this->db->get('orders');
		$rows = $query->result_array();
		foreach($rows as $row){
			//$this->db->where('order_id', $row["order_id"]);
			//$this->db->delete('bills');
			$this->db->where('order_id', $row["order_id"]);
			$this->db->delete('orders');
		}
	}
	
	public function check_users($val, $col){
		$this->db->from('users');
		$this->db->where($col, $val);
		return $this->db->get()->row_array();
	}
	
	public function check_order_by_user($orderid, $username){
		$this->db->from('orders');
		$this->db->where("order_id", $orderid);
		$this->db->where("order_email", $username);
		return $this->db->get()->row_array();
	}
	
	public function delete_order($orderid){
		$this->db->where('order_id', $orderid);
		return $this->db->delete('orders');
	}
	
	public function delete_payment($orderid){
		$this->db->where('order_id', $orderid);
		return $this->db->delete('payment');
	}
	
	public function insert_payment($data){
		$row = array(
			"id" => NULL,
			"order_id" => $data["order_id"],
			"amount" => $data["amount"],
			"img" => $data["link"],
		);
		return $this->db->insert('payment', $row);
	}
	
	public function check_payment($orderid){
		$this->db->from('payment');
		$this->db->where("order_id", $orderid);
		return $this->db->get()->row_array();
	}
	
	public function update_order($orderid){
		$this->db->where('order_id', $orderid);
		$row = array(
			"order_status" => "pending"
		);
		return $this->db->update('orders', $row);
	}
	
	public function update_order_success($orderid){
		$this->db->where('order_id', $orderid);
		$row = array(
			"order_status" => "success"
		);
		return $this->db->update('orders', $row);
	}
	
	public function update_order_waiting($orderid){
		$this->db->where('order_id', $orderid);
		$row = array(
			"order_status" => "waiting"
		);
		return $this->db->update('orders', $row);
	}
	
	public function update_order_deny($orderid){
		$this->db->where('order_id', $orderid);
		$row = array(
			"order_status" => "deny"
		);
		return $this->db->update('orders', $row);
	}
	
	public function get_bill_by_user($username){
		$tmp_row = $this->get_order_by_user($username);
		
		$real_row = array();
		$i=0;
		foreach($tmp_row as $row){
			$this->db->from('bills');
			$this->db->where("order_id", $row["order_id"]);
			$tmp_row_bill = $this->db->get()->result_array();
			for($j=0;$j<count($tmp_row_bill);$j++){
				$real_row[$i] = $tmp_row_bill[$j];
				$i++;
			}
		}
		return $real_row;
	}
	
	public function get_bill_by_id($bid){
		$this->db->from('bills');
		$this->db->where("b_id", $bid);
		return $this->db->get()->row_array();
	}
}
